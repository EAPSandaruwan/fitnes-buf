class UserModel {
  String? uid;
  String name;
  String email;
  int age;
  double height; // in cm
  double weight; // in kg
  String gender;

  String? fitnessLevel;

  UserModel({
    this.uid,
    required this.name,
    required this.email,
    required this.age,
    required this.height,
    required this.weight,
    required this.gender,
    this.fitnessLevel,
  });

  // Convert object to Map (for Firebase storage)
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'email': email,
      'age': age,
      'height': height,
      'weight': weight,
      'gender': gender,
      'fitness_level' : fitnessLevel,
    };
  }

  // Convert Map to UserModel object
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'],
      name: map['name'],
      email: map['email'],
      age: map['age'],
      height: map['height'],
      weight: map['weight'],
      gender: map['gender'],
      fitnessLevel: map['fitnessLevel'],
    );
  }

  // Calculate BMI
  double calculateBMI() {
    double heightInMeters = height / 100;
    return weight / (heightInMeters * heightInMeters);
  }

  // Get BMI Category
  String getBMICategory() {
    double bmi = calculateBMI();
    if (bmi < 18.5) {
      return "Underweight";
    } else if (bmi >= 18.5 && bmi <= 24.9) {
      return "Normal Weight";
    } else if (bmi >= 24.5 && bmi <= 29.9) {
      return "Overweight";
    } else {
      return "Obese";
    }
  }
}
