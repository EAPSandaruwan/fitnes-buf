class ProgressModel {
  String userId;
  DateTime date;
  int workoutMinutes;
  int caloriesBurned;
  double weight;


  ProgressModel({
    required this.userId,
    required this.date,
    required this.workoutMinutes,
    required this.caloriesBurned,
    required this.weight,
  });

  // Convert object to Map
  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'date': date.toIso8601String(),
      'workoutMinutes': workoutMinutes,
      'caloriesBurned': caloriesBurned,
      'weight': weight,
    };
  }

  // Convert Map to ProgressModel object
  factory ProgressModel.fromMap(Map<String, dynamic> map) {
    return ProgressModel(
      userId: map['userId'],
      date: DateTime.parse(map['date']),
      workoutMinutes: map['workoutMinutes'],
      caloriesBurned: map['caloriesBurned'],
      weight: map['weight'],
    );
  }
}
