class WorkoutModel {
  String id;
  String name;
  String category;
  int duration;
  int caloriesBurned;
  List<Map<String, dynamic>> exercises;
  String? fitnessLevel;

  WorkoutModel({
    required this.id,
    required this.name,
    required this.category,
    required this.duration,
    required this.caloriesBurned,
    required this.exercises,
    required this.fitnessLevel,
  });

  // Convert Object to the Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'duration': duration,
      'fitnessLevel':fitnessLevel,
      'caloriesBurned': caloriesBurned,
      'exercises':
          exercises
              .map(
                (exercise) => {
                  'name': exercise['name'],
                  'image': exercise['image'],
                  'duration': {
                    'minutes': exercise['duration']['minutes'],
                    'seconds': exercise['duration']['seconds'],
                  },
                },
              )
              .toList(),
    };
  }

  // Convert Map to WorkoutModel Object
  // Convert Map to WorkoutModel object
  factory WorkoutModel.fromMap(Map<String, dynamic> map) {
    return WorkoutModel(
      id: map['id'],
      name: map['name'],
      category: map['category'],
      duration: map['duration'],
      caloriesBurned: map['caloriesBurned'],
      fitnessLevel: map['fitnessLevel'],
      exercises: List<Map<String, dynamic>>.from(
        map['exercises'].map(
          (exercise) => {
            'name': exercise['name'],
            'image': exercise['image'],
            'duration': {
              'minutes': exercise['duration']['minutes'],
              'seconds': exercise['duration']['seconds'],
            },
          },
        ),
      ),
    );
  }
}
