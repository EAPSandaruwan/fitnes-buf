import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors
  static const Color primaryPurple = Color(0xFF8C52FF);
  static const Color primaryBlue = Color(0xFF5E5CE6);
  static const Color accentPink = Color(0xFFFF2D55);
  static const Color accentTeal = Color(0xFF00F5E9);

  // Dark Theme Colors
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E1E);
  static const Color darkCard = Color(0xFF2A2A2A);

  // Text Colors
  static const Color textPrimary = Color(0xFFF0F0F0);
  static const Color textSecondary = Color(0xFFB0B0B0);

  // Gradient Colors
  static const List<Color> purpleGradient = [primaryPurple, primaryBlue];

  static const List<Color> accentGradient = [accentPink, accentTeal];
}
