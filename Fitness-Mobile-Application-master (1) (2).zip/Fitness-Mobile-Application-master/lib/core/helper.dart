import 'package:flutter/material.dart';

import 'constant.dart';

class Helper {
  static void showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
    );
  }

  static BoxDecoration gradientBoxDecoration(List<Color> colors) {
    return BoxDecoration(
      gradient: LinearGradient(
        colors: colors,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(15),
    );
  }


  static Color getBmiCategoryColor(String category) {
    switch (category) {
      case 'Underweight':
        return Colors.blue;
      case 'Normal weight':
        return Colors.green;
      case 'Overweight':
        return Colors.orange;
      case 'Obesity':
        return Colors.red;
      default:
        return AppColors.textPrimary;
    }
  }

  static String getBmiMessage(String category) {
    switch (category) {
      case 'Underweight':
        return 'You may need to gain some weight. Consider consulting with a nutritionist for a balanced diet plan.';
      case 'Normal weight':
        return 'You have a healthy weight. Keep up your good habits!';
      case 'Overweight':
        return 'You may benefit from losing some weight. Consider increasing physical activity and watching your diet.';
      case 'Obesity':
        return 'It\'s advisable to lose weight for health benefits. Consider consulting with a healthcare professional.';
      default:
        return '';
    }
  }


}
