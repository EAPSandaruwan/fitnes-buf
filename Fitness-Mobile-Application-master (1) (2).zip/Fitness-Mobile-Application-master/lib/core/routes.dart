import 'package:fitness_buddy_mobile/views/bmi_screen.dart';
import 'package:fitness_buddy_mobile/views/chatbot_screen.dart';
import 'package:fitness_buddy_mobile/views/getStart_screen.dart';
import 'package:fitness_buddy_mobile/views/progress_screen.dart';
import 'package:fitness_buddy_mobile/views/register_screen.dart';
import 'package:fitness_buddy_mobile/views/resource_screen.dart';
import 'package:fitness_buddy_mobile/views/workout_screen.dart';
import 'package:flutter/material.dart';
import '../views/dashboard_screen.dart';
import '../views/layout/layout_screen.dart';
import '../views/login_screen.dart';
import '../views/profile_screen.dart';

class Routes {
  static const String getStart = '/get-start';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';
  static const String initial = getStart;
  static const String profile = '/profile';
  static const String workouts = '/workouts';
  static const String workoutDetails = '/workout-details';
  static const String bmiCalculator = '/bmi';
  static const String resources = '/resources';
  static const String chatbot = '/chatbot';
  static const String progress = '/progress';

  static Map<String,WidgetBuilder> getRoutes(){
    return{
      getStart:(context) => const GetStartedScreen(),
      login:(context) => const LoginScreen(),
      register: (context) => const RegisterScreen(),
      home : (context) => const LayoutScreen(),
      workouts: (context) => const WorkoutScreen(),
      progress : (context) => const ProgressScreen(),
      chatbot : (context) => const ChatbotScreen(),
      bmiCalculator: (context) => const BMICalculatorScreen(),
      profile : (context) => const ProfileScreen(),
      resources: (context) => const ResourcesScreen(),
    };
  }
}
