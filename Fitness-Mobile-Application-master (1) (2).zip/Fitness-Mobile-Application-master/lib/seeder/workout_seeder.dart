import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';
import 'dart:typed_data';

import '../models/workout_model.dart';

class WorkoutSeeder {
  final _storage = FirebaseStorage.instance;
  final _firestore = FirebaseFirestore.instance;

  final List<String> gifNames = [
    'bicycle_crunches',
    'burpees',
    'calf_raise',
    'crunches',
    'glute_kick',
    'jumping_jacks',
    'plank',
    'side_bend',
    'sit_ups',
    'squat_jumps',
    'squat',
    'step_ups',
    'wall_sits',
    'pushups',
    'curtsy_lunges',
    'lunges',
    'side_lunges',
    'pile_squats',
  ];

  Future<void> seedWorkout() async {
    final allExercises = await _uploadExercises(); // Upload all exercises once

    final levelsWithCounts = {
      'Beginner': 8,
      'Intermediate': 10,
      'Hard': allExercises.length,
    };

    for (var entry in levelsWithCounts.entries) {
      final level = entry.key;
      final count = entry.value;

      final selectedExercises = allExercises.sublist(0, count);

      final workout = WorkoutModel(
        id: const Uuid().v4(),
        name: 'Full Body $level Workout',
        category: 'Full Body',
        duration: 30,
        caloriesBurned: 200,
        fitnessLevel: level,
        exercises: selectedExercises,
      );

      await _firestore.collection('workouts').doc(workout.id).set(workout.toMap());
      print('Workout seeded for $level');
    }
  }

  Future<List<Map<String, dynamic>>> _uploadExercises() async {
    List<Map<String, dynamic>> exercises = [];

    for (String name in gifNames) {
      final gifPath = 'assets/gifs/$name.gif';
      final Uint8List bytes = await rootBundle.load(gifPath).then((bd) => bd.buffer.asUint8List());

      final ref = _storage.ref().child('exercise_gifs/$name.gif');
      final task = await ref.putData(bytes, SettableMetadata(contentType: 'image/gif'));
      final imageUrl = await task.ref.getDownloadURL();

      exercises.add({
        'name': name.replaceAll('_', ' ').toUpperCase(),
        'image': imageUrl,
        'duration': {'minutes': 0, 'seconds': 30},
      });
    }

    return exercises;
  }
}
