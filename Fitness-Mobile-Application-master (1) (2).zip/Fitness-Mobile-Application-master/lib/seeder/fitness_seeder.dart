import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/progress_model.dart';

class ProgressSeeder {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final Random _random = Random();

  // Number of past days to generate progress for
  final int numberOfDays = 7;

  Future<void> seedProgress() async {
    try {
      final usersSnapshot = await _firestore.collection('users').get();

      for (var userDoc in usersSnapshot.docs) {
        final userId = userDoc.id;

        for (int i = 0; i < numberOfDays; i++) {
          final date = DateTime.now().subtract(Duration(days: i));

          final progress = ProgressModel(
            userId: userId,
            date: date,
            workoutMinutes: _random.nextInt(30) + 10, // 10 to 40 mins
            caloriesBurned: _random.nextInt(300) + 100, // 100 to 400 calories
            weight: 50 + _random.nextDouble() * 30, // 50kg to 80kg range
          );

          await _firestore
              .collection('progress')
              .doc('${userId}_${date.toIso8601String()}')
              .set(progress.toMap());

          print('Progress added for user $userId on ${date.toLocal()}');
        }
      }

      print('Progress seeding completed!');
    } catch (e) {
      print(' Error seeding progress: $e');
    }
  }
}
