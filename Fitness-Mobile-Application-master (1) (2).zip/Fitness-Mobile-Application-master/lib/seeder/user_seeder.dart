import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/user_model.dart';


class UserSeeder {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Function to create a user
  Future<void> seedUsers() async {
    // List of users to add
    List<UserModel> users = [
      UserModel(
        uid: const Uuid().v4(),
        name: 'John Doe',
        email: 'john.doe@example.com',
        age: 30,
        height: 175,
        weight: 70,
        gender: 'Male',
        fitnessLevel: 'Intermediate',
      ),
      UserModel(
        uid: const Uuid().v4(),
        name: 'Jane Smith',
        email: 'jane.smith@example.com',
        age: 25,
        height: 160,
        weight: 55,
        gender: 'Female',
        fitnessLevel: 'Beginner',
      ),
      UserModel(
          uid: const Uuid().v4(),
          name: 'Johnny Silva',
          email: 'johnnysilva@example.com',
          age: 22,
          height: 150,
          weight: 60,
          gender: 'Male',
          fitnessLevel: 'Hard'
      ),
    ];

    for (var user in users) {
      try {
        // Create the user in Firebase Authentication
        UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: user.email,
          password: 'password123', // You should generate a password or allow the user to set one
        );
        User? firebaseUser = userCredential.user;

        if (firebaseUser != null) {
          await _firestore.collection('users').doc(firebaseUser.uid).set(user.toMap());

          print('User ${user.name} added successfully');
        }
      } catch (e) {
        print('Error adding user ${user.name}: $e');
      }
    }
  }
}
