import 'package:fitness_buddy_mobile/models/chat_model.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../core/constant.dart';
import '../core/helper.dart';

class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  State<ChatbotScreen> createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessageModel> _messages = [];
  bool _isTyping = false;
  late GenerativeModel _model;
  late ChatSession _chatSession;
  late DatabaseReference _chatRef;
  late String _userId;

  // Animation controllers similar to login screen
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _userId = FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';
    _chatRef = FirebaseDatabase.instance.ref().child('chats').child(_userId);

    // Initialize animations just like login screen
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(
        begin: 0.0,
        end: 1.0
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _animationController.forward();

    // Initialize Gemini model (formerly Bard)
    _model = GenerativeModel(
      model: 'gemini-2.0-flash',
      apiKey: 'AIzaSyDAGkPnsZTLr_x5gSUr9PsLPIQgH39PIrw ', // Store this securely
    );

    _chatSession = _model.startChat(
      history: [
        Content.text(
            'You are a friendly fitness assistant named Fitness Buddy. Provide concise, helpful fitness advice, workout guidance, and motivational tips. Keep responses short and focused on fitness topics.'
        )
      ],
    );

    // Load chat history from Firebase
    _loadChatHistory();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  // Load chat history from Firebase
  Future<void> _loadChatHistory() async {
    setState(() => _isTyping = true);

    try {
      final snapshot = await _chatRef.get();
      if (snapshot.exists) {
        final data = snapshot.value as Map<dynamic, dynamic>;

        List<ChatMessageModel> loadedMessages = [];
        data.forEach((key, value) {
          final message = ChatMessageModel(
            text: value['text'],
            isUser: value['isUser'],
            timestamp: DateTime.fromMillisecondsSinceEpoch(value['timestamp']),
          );
          loadedMessages.add(message);
        });

        // Sort messages by timestamp
        loadedMessages.sort((a, b) => a.timestamp.compareTo(b.timestamp));

        setState(() {
          _messages.addAll(loadedMessages);
        });
      }
    } catch (e) {
      Helper.showSnackBar(context, "Failed to load chat history: $e");
    } finally {
      setState(() => _isTyping = false);
    }
  }

  // Send message to Gemini and store in Firebase
  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    final userMessage = ChatMessageModel(
      text: text,
      isUser: true,
      timestamp: DateTime.now(),
    );

    setState(() {
      _messages.add(userMessage);
      _isTyping = true;
      _messageController.clear();
    });

    _saveMessageToFirebase(userMessage);
    _scrollToBottom();

    try {
      final response = await _chatSession.sendMessage(
        Content.text(text),
      );

      final botMessage = ChatMessageModel(
        text: response.text ?? "Sorry, I couldn't process that request.",
        isUser: false,
        timestamp: DateTime.now(),
      );

      setState(() {
        _messages.add(botMessage);
        _isTyping = false;
      });

      _saveMessageToFirebase(botMessage);
      _scrollToBottom();
    } catch (e) {
      setState(() => _isTyping = false);
      Helper.showSnackBar(context, "Failed to get response: $e");
    }
  }

  // Save message to Firebase Realtime Database
  Future<void> _saveMessageToFirebase(ChatMessageModel message) async {
    try {
      // Create a new entry with a unique key
      final newMessageRef = _chatRef.push();
      await newMessageRef.set({
        'text': message.text,
        'isUser': message.isUser,
        'timestamp': message.timestamp.millisecondsSinceEpoch,
      });
    } catch (e) {
      Helper.showSnackBar(context, "Failed to save message: $e");
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background gradient - same as login screen
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF121212),
                  Color(0xFF1E1E2E),
                ],
              ),
            ),
          ),

          // Background Shape - top right circle, same as login screen
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.purpleGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // Background Shape - bottom left circle, same as login screen
          Positioned(
            bottom: -120,
            left: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.accentGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accentPink.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: Column(
              children: [
                if (_messages.isEmpty)
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: Column(
                      children: [
                        const SizedBox(height: 30),
                        Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.darkCard,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryPurple.withOpacity(0.2),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              "assets/icons/logo.png",
                              fit: BoxFit.cover,
                              width: 110,
                              height: 110,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          "FITNESS BUDDY",
                          style: GoogleFonts.josefinSans(
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ),

                // Messages and input area
                Expanded(
                  child: _messages.isEmpty
                      ? _buildWelcomeMessage()
                      : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      return _buildMessageBubble(_messages[index]);
                    },
                  ),
                ),

                // Typing indicator
                if (_isTyping)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.darkCard,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Row(
                            children: [
                              const SizedBox(width: 8),
                              SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(AppColors.accentPink),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Typing...',
                                style: TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                // Input field with animation
                SlideTransition(
                  position: _slideAnimation,
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: _buildMessageInput(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeMessage() {
    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              Text(
                "Your Personal Coach!",
                style: GoogleFonts.josefinSans(
                  fontSize: 24,
                  letterSpacing: 1.2,
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Ask me anything about workouts, nutrition, or fitness goals. I'm here to guide you!",
                style: GoogleFonts.montserrat(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 40),
              Text(
                "Try asking:",
                style: GoogleFonts.montserrat(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _buildSuggestionChips(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSuggestionChips() {
    final suggestions = [
      "Recommend a quick workout",
      "How to improve my form?",
      "Nutrition tips for recovery",
      "Help me stay motivated"
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 12,
      children: suggestions.map((suggestion) {
        return Container(
          decoration: Helper.gradientBoxDecoration(AppColors.purpleGradient),
          child: ActionChip(
            backgroundColor: Colors.transparent,
            label: Text(
              suggestion,
              style: GoogleFonts.montserrat(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
            onPressed: () => _sendMessage(suggestion),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildMessageBubble(ChatMessageModel message) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: message.isUser
              ? const LinearGradient(
            colors: AppColors.purpleGradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
              : null,
          color: message.isUser ? null : AppColors.darkCard,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              message.text,
              style: GoogleFonts.montserrat(
                color: message.isUser
                    ? Colors.white
                    : AppColors.textPrimary,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _formatTimestamp(message.timestamp),
              style: GoogleFonts.montserrat(
                color: message.isUser
                    ? Colors.white70
                    : AppColors.textSecondary,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTimestamp(DateTime timestamp) {
    return '${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}';
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.transparent,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: AppColors.darkCard,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppColors.textSecondary.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _messageController,
                decoration: InputDecoration(
                  hintText: 'Ask your fitness coach...',
                  hintStyle: TextStyle(color: AppColors.textSecondary),
                  border: InputBorder.none,
                ),
                style: TextStyle(color: AppColors.textPrimary),
                maxLines: null,
                textCapitalization: TextCapitalization.sentences,
                onSubmitted: _isTyping ? null : _sendMessage,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: AppColors.purpleGradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: IconButton(
              onPressed: _isTyping
                  ? null
                  : () => _sendMessage(_messageController.text),
              icon: const Icon(
                Icons.send_rounded,
                color: Colors.white,
              ),
              tooltip: 'Send message',
            ),
          ),
        ],
      ),
    );
  }
}
