import 'package:fitness_buddy_mobile/core/routes.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constant.dart';
import '../core/helper.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation <double> _fadeAnimation;
  late Animation <Offset> _slideAnimation;

  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isPasswordVisible = false;
  bool _isLoading = false;


  @override  
  void initState(){
    super.initState();

    _animationController = AnimationController(vsync: this,duration: const Duration(milliseconds: 800),);
    _fadeAnimation = Tween<double>(begin: 0.0,end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut,),
    );

    _animationController.forward();
  }

  @override
  void dispose(){
    _animationController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _togglePasswordVisibility(){
    setState(() {
      _isPasswordVisible = !_isPasswordVisible;
    });
  }

  void _handleLogin() async {
    if (_formKey.currentState?.validate() ?? false) {
      final prefs = await SharedPreferences.getInstance();
      String email = _emailController.text.trim();
      String password = _passwordController.text.trim();

      setState(() {
        _isLoading = true;
      });

      try {
        // Sign in with Firebase Auth
        UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: password,
        );

        String? uid = userCredential.user?.uid;

        if (uid != null) {
          DocumentSnapshot userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(uid)
              .get();

          if (userDoc.exists) {
            Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;
            await prefs.setString('uid', uid);
            await prefs.setString('email', email);
            await prefs.setString('fullName', userData['name'] ?? '');
            await prefs.setString('gender', userData['gender'] ?? '');
            await prefs.setDouble('height', userData['height'] ?? '');
            await prefs.setString('fitness_level', userData['fitness_level'] ?? '');
            await prefs.setDouble('weight', userData['weight'] ?? '');
            await prefs.setInt('age', userData['age'] ?? '');

            Helper.showSnackBar(context, "Welcome back, ${userData['name']}!");

            // Navigate if needed
            Navigator.pushReplacementNamed(context, '/home');
          } else {
            Helper.showSnackBar(context, "User data not found in Firestore.");
          }
        } else {
          Helper.showSnackBar(context, "Login failed: Invalid user ID.");
        }

      } on FirebaseAuthException catch (e) {
        String message;
        switch (e.code) {
          case 'user-not-found':
            message = 'No user found for that email.';
            break;
          case 'wrong-password':
            message = 'Wrong password provided.';
            break;
          default:
            message = 'Login failed: ${e.message}';
        }
        Helper.showSnackBar(context, message);
      } catch (error) {
        Helper.showSnackBar(context, "Unexpected error: ${error.toString()}");
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }


  // Google Sign in function
  Future<void> _handleGoogleSignIn() async {
    try{
      // Sign in with google
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if(googleUser == null) return;
      
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to the firebase
      UserCredential userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
      User? user = userCredential.user;
      if(user == null) return;

      // Refer to firestore collection
      DocumentReference userRef = FirebaseFirestore.instance.collection('users').doc(user.uid);

      // Check user is exist in firestore
      DocumentSnapshot userDoc = await userRef.get();
      if(!userDoc.exists){
        // If user does not exist, create a new record
        await userRef.set({
          'uid': user.uid,
          'name': user.displayName,
          'email': user.email,
          'profileImage': user.photoURL,
          'createdAt': FieldValue.serverTimestamp(),

        });
        print("New user created in Firestore: ${user.displayName}");
      }else{
        print("User already exists in Firestore: ${user.displayName}");
      }
    }catch(error){
      print('Google Sign-In Failed: $error');
    }
  }

  @override
  Widget build (BuildContext context){
    return Scaffold(
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(begin:Alignment.topLeft,end: Alignment.bottomRight,colors: [
                Color(0xFF121212),
                Color(0xFF1E1E2E),
              ],
              ),
            ),
          ),
          // Background Shape
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.purpleGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            bottom: -120,
            left: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.accentGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accentPink.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),
          // Login Content
          SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 30),

                    Center(
                      child: FadeTransition(
                        opacity: _fadeAnimation,
                        child: Column(
                          children: [
                            Container(
                              width: 120, // Increased size
                              height: 120, // Increased size
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColors.darkCard,
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.primaryPurple.withOpacity(0.2),
                                    blurRadius: 20,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: ClipOval(
                                child: Image.asset(
                                  "assets/icons/logo.png",
                                  fit: BoxFit.cover,
                                  width: 110, // Ensure image fills the space
                                  height: 110,
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            Text(
                              "FITNESS BUDDY",
                              style: GoogleFonts.josefinSans(
                                fontSize: 36,
                                fontWeight: FontWeight.bold, // Adjust as needed
                                color: AppColors.textPrimary, // Use your color variable or replace with Colors.black
                                letterSpacing: 1.2, // Optional, for better text spacing
                                fontStyle: FontStyle.normal, // Use FontStyle.italic if you want italics
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 60),



                    // Welcome Text
                    SlideTransition(position: _slideAnimation,
                      child: FadeTransition(
                          opacity: _fadeAnimation,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Welcome Back!",
                              style: GoogleFonts.josefinSans(
                                fontSize: 24,
                                letterSpacing: 1.2,
                                color: AppColors.textPrimary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8,),
                            Text(
                              "Log in to continue your fitness journey",
                              style: GoogleFonts.montserrat(
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.bold,
                              ),

                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 40,),

                    // Login Form
                    SlideTransition(
                      position: _slideAnimation,
                      child: FadeTransition(opacity: _fadeAnimation,
                        child: Form(key:_formKey,child: Column(
                          children: [
                            // Email Field
                            TextFormField(
                              controller: _emailController,
                              decoration: InputDecoration(
                                labelText: "Email",
                                prefixIcon: const Icon(Icons.mail_outline,color: AppColors.textSecondary,),
                                labelStyle: TextStyle(color: AppColors.textSecondary,)
                              ),
                              style: TextStyle(color: AppColors.textPrimary),
                              keyboardType: TextInputType.emailAddress,
                              validator: (value){
                                if(value == null || value.isEmpty){
                                  return "Please enter your email";
                                }
                                if(!value.contains('@')){
                                  return "Please enter a valid email";
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 20,),
                            // Password Field
                            TextFormField(
                              controller: _passwordController,
                              obscureText: !_isPasswordVisible,
                              decoration: InputDecoration(
                                labelText: "Password",
                                prefixIcon: const Icon(Icons.lock_outline,color: AppColors.textSecondary,),
                                suffixIcon: IconButton(icon: Icon(_isPasswordVisible ? Icons.visibility : Icons.visibility_off, color: AppColors.textSecondary,),
                                  onPressed: _togglePasswordVisibility,
                                ),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: TextStyle(color: AppColors.textPrimary),
                              validator: (value){
                                if(value == null || value.isEmpty){
                                  return "Please enter your password";
                                }
                                if (value.length < 6){
                                  return "Password must be at least 6 characters";
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            // Forgot Password
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(onPressed: (){
                                // Implement forget password logic
                              }, child: Text(
                                    "Forgot Password?",
                                    style: TextStyle(
                                      color: AppColors.accentPink,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Poppins'
                                    ),
                                  ),
                              ),
                            ),

                            const SizedBox(height: 30,),

                            // Login Button
                            Container(
                              width: double.infinity,
                              height: 55,
                              decoration: Helper.gradientBoxDecoration(AppColors.purpleGradient),
                              child: ElevatedButton(onPressed: _handleLogin, style: ElevatedButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                elevation: 0,
                              ),
                                  child: const Text(
                                    "Login",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "Poppins",
                                      letterSpacing: 1.2,
                                    ),
                                  ),
                              ),
                            ),

                            const SizedBox(height: 30,),
                            // Sign up Text
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Don't have an account?",
                                  style: GoogleFonts.montserrat(
                                    color: AppColors.textSecondary,
                                    fontWeight: FontWeight.bold,
                                    decorationColor: AppColors.accentPink,
                                  ),

                                ),
                                TextButton(
                                    onPressed:(){
                                      Navigator.pushNamed(context, Routes.register);
                                    },
                                    child: Text(
                                      "Sign Up",
                                      style: GoogleFonts.montserrat(
                                        color: AppColors.accentPink,
                                        fontWeight: FontWeight.bold,
                                        decoration: TextDecoration.underline,
                                        decorationColor: AppColors.accentPink,
                                      ),

                                    ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30,),

                    // Social Login Options
                    SlideTransition(position: _slideAnimation,
                      child: FadeTransition(opacity: _fadeAnimation, child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(child: Divider(color: AppColors.textSecondary.withOpacity(0.3))),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                child: Text(
                                  "OR CONTINUE WITH",
                                  style: GoogleFonts.montserrat( // Correct way to use Google Fonts
                                    color: AppColors.textSecondary,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Expanded(child: Divider(color: AppColors.textSecondary.withOpacity(0.3))),
                            ],

                          ),
                          const SizedBox(height: 20),
                          // Social Login Button
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _buildSocialButton(
                                icon: Icons.g_mobiledata,
                                color:Colors.red,
                                onPressed:_handleGoogleSignIn,
                              ),
                              const SizedBox(width: 20,),
                              _buildSocialButton(
                                icon: Icons.facebook,
                                color:Colors.blue,
                                onPressed:(){},
                              ),
                              const SizedBox(width: 20,),
                              _buildSocialButton(
                                icon: Icons.apple,
                                color: Colors.white,
                                onPressed: () {},
                              ),
                            ],
                          )
                        ],
                      ),),
                    )

                  ],
                ),
              ))
        ],
      ),
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.darkCard,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon, color: color, size: 30),
        onPressed: onPressed,
        padding: const EdgeInsets.all(12),
      ),
    );
  }
}

