import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../core/constant.dart';

class ResourcesScreen extends StatefulWidget {
  const ResourcesScreen({Key? key}) : super(key: key);

  @override
  State<ResourcesScreen> createState() => _ResourcesScreenState();
}

class _ResourcesScreenState extends State<ResourcesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = true;
  List<dynamic> _fitnessVideos = [];
  List<dynamic> _musicPlaylists = [];
  List<dynamic> _spotifyPlaylists = [];
  final String _youtubeApiKey = 'AIzaSyBWVWWhasonE9Z_IcorpWHc1jC6n-TzxgI';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _fetchYouTubeResources();
    _loadMusicPlaylists();
    _loadSpotifyPlaylists();
  }

  Future<void> _fetchYouTubeResources() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Change query to get varied content on each load
      final queries = [
        'beginner workout tutorials',
        'hiit workout at home',
        'cardio exercises tutorials',
        'weight training for beginners',
        'yoga tutorials',
        'pilates workout',
        'stretching exercises',
        'bodyweight workout'
      ];

      final randomQuery = queries[DateTime.now().millisecondsSinceEpoch % queries.length];

      final response = await http.get(
        Uri.parse('https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=$randomQuery&type=video&key=$_youtubeApiKey'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _fitnessVideos = data['items'];
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
          // Fallback to sample data if API fails
          _fitnessVideos = _getSampleVideoData();
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        // Fallback to sample data if API fails
        _fitnessVideos = _getSampleVideoData();
      });
    }
  }

  void _loadMusicPlaylists() {
    // Sample YouTube Music playlists
    _musicPlaylists = [
      {
        'id': 'PL4fGSI1pDJn6jXS_Tv_N9B8Z0HTRVJE0m',
        'title': 'Workout Beats',
        'thumbnail': 'https://i.ytimg.com/vi/5qap5aO4i9A/maxresdefault.jpg',
        'channelTitle': 'YouTube Music',
        'description': 'High energy tracks to power your workout'
      },
      {
        'id': 'PL4fGSI1pDJn40YZqfN-EefHwrPlUVdOFh',
        'title': 'Cardio Pump',
        'thumbnail': 'https://i.ytimg.com/vi/rPzC1o4yMFs/maxresdefault.jpg',
        'channelTitle': 'YouTube Music',
        'description': 'Fast-paced beats for intense cardio sessions'
      },
      {
        'id': 'PL4fGSI1pDJn6puJdseH2Rt9sMvt9E2M4i',
        'title': 'Cool Down Vibes',
        'thumbnail': 'https://i.ytimg.com/vi/lTRiuFIWV54/maxresdefault.jpg',
        'channelTitle': 'YouTube Music',
        'description': 'Relaxing tracks for post-workout stretching'
      },
      {
        'id': 'PL4fGSI1pDJn69On1f-8NAvX_CYlx7QyZc',
        'title': 'Running Mix',
        'thumbnail': 'https://i.ytimg.com/vi/khkQHZDYO_A/maxresdefault.jpg',
        'channelTitle': 'YouTube Music',
        'description': 'Steady tempo tracks for your running sessions'
      },
      {
        'id': 'PL4fGSI1pDJn5rS-COo4RR0SL8td2q7-cL',
        'title': 'Strength Training',
        'thumbnail': 'https://i.ytimg.com/vi/zzWZo0HYrpM/maxresdefault.jpg',
        'channelTitle': 'YouTube Music',
        'description': 'Heavy beats for lifting and strength exercises'
      },
    ];
  }

  void _loadSpotifyPlaylists() {
    // Sample Spotify playlists
    _spotifyPlaylists = [
      {
        'id': '37i9dQZF1DX76Wlfdnj7AP',
        'title': 'Beast Mode',
        'thumbnail': 'https://i.scdn.co/image/ab67706f00000003a4a14452153e0e4b00b0a535',
        'creator': 'Spotify',
        'description': 'Heavy hitting tracks that will inspire you to go hard.'
      },
      {
        'id': '37i9dQZF1DWUSyphfcc6aL',
        'title': 'Gym Flow',
        'thumbnail': 'https://i.scdn.co/image/ab67706f000000034e0046bc8a8557a3b320a91a',
        'creator': 'Spotify',
        'description': 'Hit your next PR with these high-energy tracks.'
      },
      {
        'id': '37i9dQZF1DX70RN3TfWWJh',
        'title': 'Workout Twerkout',
        'thumbnail': 'https://i.scdn.co/image/ab67706f00000003f48ce8e58aeed2bf5abc8d02',
        'creator': 'Spotify',
        'description': 'Booty-activating beats for your workout.'
      },
      {
        'id': '37i9dQZF1DX0HRj9P7NxeE',
        'title': 'Workout Hip-Hop',
        'thumbnail': 'https://i.scdn.co/image/ab67706f000000036d5c709642bfb5eb760918d2',
        'creator': 'Spotify',
        'description': 'New and classic hip-hop tracks to soundtrack your workout.'
      },
      {
        'id': '37i9dQZF1DX32NsLKyzScr',
        'title': 'Power Hour',
        'thumbnail': 'https://i.scdn.co/image/ab67706f0000000387bfe8739495b54566a8f104',
        'creator': 'Spotify',
        'description': '60 minutes of pumped up songs for your workout.'
      },
    ];
  }

  List<dynamic> _getSampleVideoData() {
    // Sample data to use when API fails
    return [
      {
        'id': {'videoId': 'UBMk30rjy0o'},
        'snippet': {
          'title': '20 Minute Full Body Workout - Beginner Version',
          'thumbnails': {'high': {'url': 'https://i.ytimg.com/vi/UBMk30rjy0o/hqdefault.jpg'}},
          'channelTitle': 'MadFit',
          'description': 'Full body workout that you can do at home with no equipment'
        }
      },
      {
        'id': {'videoId': 'ml6cT4AZdqI'},
        'snippet': {
          'title': '30-Minute HIIT Cardio Workout with Warm Up',
          'thumbnails': {'high': {'url': 'https://i.ytimg.com/vi/ml6cT4AZdqI/hqdefault.jpg'}},
          'channelTitle': 'SELF',
          'description': 'No equipment HIIT workout at home'
        }
      },
      {
        'id': {'videoId': '2MoGxae-zyo'},
        'snippet': {
          'title': 'Full Week Gym Workout Plan',
          'thumbnails': {'high': {'url': 'https://i.ytimg.com/vi/2MoGxae-zyo/hqdefault.jpg'}},
          'channelTitle': 'THENX',
          'description': 'Complete gym workout for one week'
        }
      },
      {
        'id': {'videoId': 'VHyGqsPOUHs'},
        'snippet': {
          'title': '15 Minute Beginner Weight Training Workout',
          'thumbnails': {'high': {'url': 'https://i.ytimg.com/vi/VHyGqsPOUHs/hqdefault.jpg'}},
          'channelTitle': 'HASfit',
          'description': 'Simple weight training for beginners'
        }
      },
      {
        'id': {'videoId': 'IT94xC35u6k'},
        'snippet': {
          'title': '15 Min Daily Stretch Routine',
          'thumbnails': {'high': {'url': 'https://i.ytimg.com/vi/IT94xC35u6k/hqdefault.jpg'}},
          'channelTitle': 'MadFit',
          'description': 'Full body stretching routine for flexibility'
        }
      },
    ];
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      // Try opening in an in-app web view
      await launchUrl(uri, mode: LaunchMode.inAppWebView);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open $url')),
      );
    }
  }

  Widget _buildTutorialItem(dynamic video) {
    final videoId = video['id']['videoId'];
    final snippet = video['snippet'];
    final title = snippet['title'];
    final thumbnailUrl = snippet['thumbnails']['high']['url'];
    final channelTitle = snippet['channelTitle'];

    return GestureDetector(
      onTap: () => _launchURL('https://www.youtube.com/watch?v=$videoId'),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: BoxDecoration(
          color: AppColors.darkCard,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CachedNetworkImage(
                    imageUrl: thumbnailUrl,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      height: 180,
                      color: Colors.grey[900],
                      child: const Center(child: CircularProgressIndicator()),
                    ),
                    errorWidget: (context, url, error) => Container(
                      height: 180,
                      color: Colors.grey[900],
                      child: const Icon(Icons.error),
                    ),
                  ),
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.8),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.play_arrow,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.montserrat(
                      color: AppColors.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    channelTitle,
                    style: GoogleFonts.montserrat(
                      color: AppColors.textSecondary,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMusicPlaylistItem(dynamic playlist, bool isSpotify) {
    final title = playlist['title'];
    final thumbnailUrl = playlist['thumbnail'];
    final creator = isSpotify ? playlist['creator'] : playlist['channelTitle'];
    final description = playlist['description'];
    final id = playlist['id'];

    return GestureDetector(
      onTap: () {
        if (isSpotify) {
          _launchURL('https://open.spotify.com/playlist/$id');
        } else {
          _launchURL('https://www.youtube.com/playlist?list=$id');
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: BoxDecoration(
          color: AppColors.darkCard,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
              child: CachedNetworkImage(
                imageUrl: thumbnailUrl,
                height: 120,
                width: 120,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  height: 120,
                  width: 120,
                  color: Colors.grey[900],
                  child: const Center(child: CircularProgressIndicator()),
                ),
                errorWidget: (context, url, error) => Container(
                  height: 120,
                  width: 120,
                  color: Colors.grey[900],
                  child: isSpotify
                      ? Icon(Icons.music_note, color: Colors.green, size: 40)
                      : Icon(Icons.music_note, color: Colors.red, size: 40),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.montserrat(
                        color: AppColors.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      creator,
                      style: GoogleFonts.montserrat(
                        color: isSpotify ? Colors.green : Colors.red,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: GoogleFonts.montserrat(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "FITNESS RESOURCES",
          style: GoogleFonts.josefinSans(
            color: AppColors.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
      ),
      body: Stack(
        children: [
          // Background gradient is already in your layout screen

          // Content
          Column(
            children: [
              Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: AppColors.darkCard.withOpacity(0.3),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
              ),
              child: TabBar(
                controller: _tabController,
                indicatorSize: TabBarIndicatorSize.label,
                indicator: UnderlineTabIndicator(
                  borderSide: BorderSide(width: 3, color: AppColors.primaryPurple),
                  insets: const EdgeInsets.symmetric(horizontal: 16),
                ),
                labelColor: Colors.white,
                unselectedLabelColor: AppColors.textSecondary,
                labelStyle: GoogleFonts.montserrat(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
                unselectedLabelStyle: GoogleFonts.montserrat(
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
                tabs: [
                  Tab(
                    icon: Icon(Icons.book_outlined),
                    text: "Tutorials",
                    iconMargin: const EdgeInsets.only(bottom: 4),
                  ),
                  Tab(
                    icon: Icon(Icons.music_note),
                    text: "YouTube",
                    iconMargin: const EdgeInsets.only(bottom: 4),
                  ),
                  Tab(
                    icon: Icon(Icons.multitrack_audio),
                    text: "Spotify",
                    iconMargin: const EdgeInsets.only(bottom: 4),
                  ),
                ],
              ),
              ),

              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    // Tutorials Tab
                    _isLoading
                        ? const Center(child: CircularProgressIndicator(color: AppColors.primaryPurple))
                        : RefreshIndicator(
                      onRefresh: _fetchYouTubeResources,
                      color: AppColors.primaryPurple,
                      child: ListView.builder(
                        padding: const EdgeInsets.only(top: 16, bottom: 16),
                        itemCount: _fitnessVideos.length,
                        itemBuilder: (context, index) => _buildTutorialItem(_fitnessVideos[index]),
                      ),
                    ),

                    // YouTube Music Tab
                    ListView.builder(
                      padding: const EdgeInsets.only(top: 16, bottom: 16),
                      itemCount: _musicPlaylists.length,
                      itemBuilder: (context, index) => _buildMusicPlaylistItem(_musicPlaylists[index], false),
                    ),

                    // Spotify Tab
                    ListView.builder(
                      padding: const EdgeInsets.only(top: 16, bottom: 16),
                      itemCount: _spotifyPlaylists.length,
                      itemBuilder: (context, index) => _buildMusicPlaylistItem(_spotifyPlaylists[index], true),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (_tabController.index == 0) {
            _fetchYouTubeResources();
          }
        },
        backgroundColor: AppColors.primaryPurple,
        child: const Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }
}