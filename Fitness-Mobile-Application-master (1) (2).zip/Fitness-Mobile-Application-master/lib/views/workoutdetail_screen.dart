import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constant.dart';
import '../models/workout_model.dart';
import '../models/progress_model.dart';

class WorkoutDetailsPage extends StatefulWidget {
  final WorkoutModel workout;

  const WorkoutDetailsPage({Key? key, required this.workout}) : super(key: key);

  @override
  State<WorkoutDetailsPage> createState() => _WorkoutDetailsPageState();
}

class _WorkoutDetailsPageState extends State<WorkoutDetailsPage> with TickerProviderStateMixin {
  late List<Map<String, dynamic>> exerciseList;
  int currentExerciseIndex = 0;
  bool isResting = false;
  bool isCompleted = false;
  bool isPaused = false;

  // Timer related variables
  late int totalSeconds;
  late Timer _timer;
  int _remainingSeconds = 0;

  // Animation controller for progress indicator
  late AnimationController _progressController;

  // Tracking stats
  int totalCaloriesBurned = 0;
  int totalMinutesWorkedOut = 0;
  int exercisesCompleted = 0;

  // User data for progress tracking
  String? userId;
  double? userWeight;

  @override
  void initState() {
    super.initState();
    exerciseList = List<Map<String, dynamic>>.from(widget.workout.exercises);
    _fetchUserData();
    _startExercise();
  }

  Future<void> _fetchUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('uid');
      userWeight = prefs.getDouble('weight');
    });
  }

  void _startExercise() {
    if (currentExerciseIndex >= exerciseList.length) {
      _completeWorkout();
      return;
    }

    final exercise = exerciseList[currentExerciseIndex];

    // Calculate exercise duration in seconds
    final minutes = exercise['duration']['minutes'] as int;
    final seconds = exercise['duration']['seconds'] as int;
    totalSeconds = (minutes * 60) + seconds;
    _remainingSeconds = totalSeconds;

    // Initialize animation controller for the progress indicator
    _progressController = AnimationController(
      vsync: this,
      duration: Duration(seconds: totalSeconds),
    );

    _progressController.forward();
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() {
          _remainingSeconds--;
        });
      } else {
        _timer.cancel();
        _exerciseCompleted();
      }
    });
  }

  void _exerciseCompleted() {
    exercisesCompleted++;

    // Update total calories based on exercise duration
    final exerciseDurationMinutes = totalSeconds / 60;
    // Simple calorie calculation - can be made more sophisticated
    final caloriesBurned = (exerciseDurationMinutes * 4.0).round();
    totalCaloriesBurned += caloriesBurned;
    totalMinutesWorkedOut += (totalSeconds / 60).round();

    currentExerciseIndex++;

    // Check if we need a rest period
    if (currentExerciseIndex < exerciseList.length && currentExerciseIndex % 3 == 0) {
      _startRestPeriod();
    } else {
      _progressController.dispose();
      _startExercise();
    }
  }

  void _startRestPeriod() {
    setState(() {
      isResting = true;
      _remainingSeconds = 30; // 30 seconds rest time
    });

    _progressController.dispose();
    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 30),
    );

    _progressController.forward();

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() {
          _remainingSeconds--;
        });
      } else {
        _timer.cancel();
        setState(() {
          isResting = false;
        });
        _progressController.dispose();
        _startExercise();
      }
    });
  }

  void _completeWorkout() {
    _timer.cancel();

    if (_progressController.isAnimating) {
      _progressController.dispose();
    }

    setState(() {
      isCompleted = true;
    });

    _saveProgress();
  }

  Future<void> _saveProgress() async {
    if (userId != null) {
      try {
        final now = DateTime.now();
        final progressId = '${userId}_${now.toIso8601String()}';

        final progress = ProgressModel(
          userId: userId!,
          date: now,
          workoutMinutes: totalMinutesWorkedOut,
          caloriesBurned: totalCaloriesBurned,
          weight: userWeight ?? 0.0,
        );

        await FirebaseFirestore.instance
            .collection('progress')
            .doc(progressId)
            .set(progress.toMap());

        print('Progress saved successfully!');
      } catch (e) {
        print('Error saving progress: $e');
      }
    }
  }

  void _togglePause() {
    setState(() {
      isPaused = !isPaused;

      if (isPaused) {
        _timer.cancel();
        _progressController.stop();
      } else {
        _startTimer();
        _progressController.forward(from: 1 - (_remainingSeconds / totalSeconds));
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    _progressController.dispose();
    super.dispose();
  }

  String _formatTime(int seconds) {
    final minutes = (seconds / 60).floor();
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: SafeArea(
        child: isCompleted
            ? _buildCompletionScreen()
            : _buildWorkoutInProgressScreen(),
      ),
    );
  }

  Widget _buildWorkoutInProgressScreen() {
    // If we've gone through all exercises but completion screen hasn't shown yet
    if (currentExerciseIndex >= exerciseList.length) {
      return Center(
        child: CircularProgressIndicator(color: AppColors.primaryPurple),
      );
    }

    final currentExercise = isResting
        ? null
        : exerciseList[currentExerciseIndex];

    return Column(
      children: [
        _buildAppBar(),
        Expanded(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    isResting ? "REST TIME" : widget.workout.name,
                    style: GoogleFonts.montserrat(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isResting
                        ? "Recover and breathe"
                        : "${currentExerciseIndex + 1}/${exerciseList.length} exercises",
                    style: GoogleFonts.montserrat(
                      color: AppColors.textSecondary,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 36),

                  // Exercise image
                  Container(
                    height: 300,
                    width: 300,
                    decoration: BoxDecoration(
                      color: AppColors.darkCard,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: isResting
                          ? Image.asset(
                        'assets/images/rest.png', // Add a rest image to your assets
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Center(
                            child: Icon(
                              Icons.hotel,
                              color: AppColors.accentPink,
                              size: 80,
                            ),
                          );
                        },
                      )
                          : Image.network(
                        currentExercise?['image'],
                        fit: BoxFit.cover,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Center(
                            child: CircularProgressIndicator(
                              color: AppColors.primaryPurple,
                              value: loadingProgress.expectedTotalBytes != null
                                  ? loadingProgress.cumulativeBytesLoaded /
                                  loadingProgress.expectedTotalBytes!
                                  : null,
                            ),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) {
                          return Center(
                            child: Icon(
                              Icons.fitness_center,
                              color: AppColors.accentPink,
                              size: 80,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 36),

                  // Exercise name
                  Text(
                    isResting
                        ? "Rest Period"
                        : currentExercise?['name'],
                    style: GoogleFonts.montserrat(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 22,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Time remaining
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        height: 120,
                        width: 120,
                        child: CircularProgressIndicator(
                          value: 1 - (_remainingSeconds / totalSeconds),
                          strokeWidth: 8,
                          backgroundColor: AppColors.darkCard,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            isResting ? AppColors.primaryBlue : AppColors.accentPink,
                          ),
                        ),
                      ),
                      Column(
                        children: [
                          Text(
                            _formatTime(_remainingSeconds),
                            style: GoogleFonts.montserrat(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w600,
                              fontSize: 32,
                            ),
                          ),
                          Text(
                            isResting ? "until next" : "remaining",
                            style: GoogleFonts.montserrat(
                              color: AppColors.textSecondary,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 36),

                  // Control buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: _togglePause,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.darkCard,
                          foregroundColor: AppColors.textPrimary,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(16),
                        ),
                        child: Icon(
                          isPaused ? Icons.play_arrow : Icons.pause,
                          size: 32,
                        ),
                      ),
                      const SizedBox(width: 20),
                      ElevatedButton(
                        onPressed: () {
                          // Skip to next exercise
                          _timer.cancel();
                          if (!isResting) {
                            _exerciseCompleted();
                          } else {
                            setState(() {
                              isResting = false;
                            });
                            _progressController.dispose();
                            _startExercise();
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryPurple,
                          foregroundColor: AppColors.textPrimary,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(16),
                        ),
                        child: const Icon(
                          Icons.skip_next,
                          size: 32,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        _buildProgressBar(),
      ],
    );
  }

  Widget _buildCompletionScreen() {
    final motivationalMessages = [
      "Great work! Your dedication is inspiring!",
      "You crushed it! Keep up the awesome progress!",
      "Amazing job! Your fitness journey is on fire!",
      "Fantastic workout! You're getting stronger every day!",
      "Excellent effort! Your consistency is paying off!",
    ];

    final random = DateTime.now().millisecondsSinceEpoch % motivationalMessages.length;
    final motivationalMessage = motivationalMessages[random];

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.emoji_events,
              color: Colors.amber,
              size: 80,
            ),
            const SizedBox(height: 24),
            Text(
              "Workout Complete!",
              style: GoogleFonts.montserrat(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 28,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              motivationalMessage,
              textAlign: TextAlign.center,
              style: GoogleFonts.montserrat(
                color: AppColors.textSecondary,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 36),
            _buildStatCard(
              "Calories Burned",
              "$totalCaloriesBurned kcal",
              Icons.local_fire_department,
              AppColors.accentPink,
            ),
            const SizedBox(height: 16),
            _buildStatCard(
              "Time Active",
              "$totalMinutesWorkedOut min",
              Icons.timer,
              AppColors.primaryBlue,
            ),
            const SizedBox(height: 16),
            _buildStatCard(
              "Exercises Completed",
              "$exercisesCompleted",
              Icons.fitness_center,
              AppColors.primaryPurple,
            ),
            const SizedBox(height: 36),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Return to workout screen
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryPurple,
                foregroundColor: AppColors.textPrimary,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                "Back to Workouts",
                style: GoogleFonts.montserrat(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: color,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.montserrat(
                  color: AppColors.textSecondary,
                  fontSize: 14,
                ),
              ),
              Text(
                value,
                style: GoogleFonts.montserrat(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              _showExitConfirmationDialog();
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.darkCard,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.arrow_back,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.darkCard,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.local_fire_department,
                  color: AppColors.accentPink,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  "$totalCaloriesBurned kcal",
                  style: GoogleFonts.montserrat(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Container(
        height: 10,
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.darkCard,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Stack(
          children: [
            FractionallySizedBox(
              widthFactor: (isResting ?
              (currentExerciseIndex / exerciseList.length) :
              ((currentExerciseIndex + (1 - (_remainingSeconds / totalSeconds))) / exerciseList.length)),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: AppColors.purpleGradient,
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showExitConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.darkCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            "Quit Workout?",
            style: GoogleFonts.montserrat(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            "Are you sure you want to quit this workout? Your progress will not be saved.",
            style: GoogleFonts.montserrat(
              color: AppColors.textSecondary,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
              },
              child: Text(
                "CANCEL",
                style: GoogleFonts.montserrat(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                Navigator.of(context).pop(); // Exit workout
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accentPink,
                foregroundColor: AppColors.textPrimary,
              ),
              child: Text(
                "QUIT",
                style: GoogleFonts.montserrat(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}