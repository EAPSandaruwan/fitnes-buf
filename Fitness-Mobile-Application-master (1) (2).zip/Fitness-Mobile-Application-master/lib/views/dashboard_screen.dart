import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitness_buddy_mobile/views/workoutdetail_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constant.dart';
import '../core/routes.dart';
import '../models/workout_model.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  String _userName = 'Fitness Buddy';
  String _userFitnessLevel = '';
  String _userGender = '';
  double _userWeight = 70.55;
  double _userHeight = 170.44;
  int _userAge = 22;

  WorkoutModel? _todayWorkout;
  bool _isLoading = true;
  String? _error;

  final List<Map<String, dynamic>> _featureCards = [
    {
      'title': 'BMI Calculator',
      'description': 'Monitor your health metrics',
      'icon': Icons.health_and_safety_outlined,
      'color': AppColors.accentTeal,
      'route': Routes.bmiCalculator,
    },
    {
      'title': 'Fitness Resources',
      'description': 'Tutorials and music playlists',
      'icon': Icons.video_library_outlined,
      'color': AppColors.primaryPurple,
      'route': Routes.resources,
    }
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _animationController, curve: Curves.easeIn)
    );

    _animationController.forward();
    _loadUserData().then((_) => _fetchWorkoutForUser());
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // Need to fetch data from the shared preferences
  Future<void> _loadUserData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _userName = prefs.getString('fullName') ?? 'Fitness Buddy';
        _userGender = prefs.getString('gender') ?? '';
        _userHeight = prefs.getDouble('height') ?? 170.44;
        _userWeight = prefs.getDouble('weight') ?? 70.55;
        _userFitnessLevel = prefs.getString('fitness_level') ?? 'Beginner';
        _userAge = prefs.getInt('age') ?? 22;
      });
    } catch (error) {
      print('Error loading user data from Shared Prefer : $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth < 600 ? 16.0 : 32.0,
          vertical: 16.0,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildWelcomeSection(),
            const SizedBox(height: 24),
            _buildTodayWorkoutCard(),
            const SizedBox(height: 24),
            _buildSectionTitle("Features"),
            const SizedBox(height: 16),
            _buildResponsiveFeatureCards(screenWidth),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }


  Widget _buildWelcomeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Welcome back,",
          style: GoogleFonts.montserrat(
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w500,
            fontSize: 16,
          ),
        ),
        Text(
          _userName,
          style: GoogleFonts.josefinSans(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "Let's crush your fitness goals today!",
          style: GoogleFonts.montserrat(
            color: AppColors.textSecondary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildWorkoutStat(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.montserrat(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.montserrat(
            color: Colors.white.withOpacity(0.7),
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Future<void> _fetchWorkoutForUser() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // Query workouts based on fitness level
      final snapshot = await FirebaseFirestore.instance
          .collection('workouts')
          .where('fitnessLevel', isEqualTo: _userFitnessLevel)
          .get();

      if (snapshot.docs.isEmpty) {
        setState(() {
          _error = 'No workouts found for your fitness level';
          _isLoading = false;
        });
        return;
      }

      // Get random workout for variety
      final random = Random();
      final randomIndex = random.nextInt(snapshot.docs.length);
      final workoutData = snapshot.docs[randomIndex].data();

      // Create WorkoutModel from the fetched data
      final workout = WorkoutModel.fromMap(workoutData);

      setState(() {
        _todayWorkout = workout;
        _isLoading = false;
      });
    } catch (error) {
      setState(() {
        _error = 'Failed to load workout: $error';
        _isLoading = false;
      });
      print('Error fetching workout: $error');
    }
  }

  Widget _buildTodayWorkoutCard() {
    if (_isLoading) {
      return _buildWorkoutCardSkeleton(
        child: const Center(
          child: CircularProgressIndicator(color: Colors.white),
        ),
      );
    }

    if (_error != null) {
      return _buildWorkoutCardSkeleton(
        child: Center(
          child: Text(
            _error!,
            style: GoogleFonts.montserrat(
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      );
    }

    if (_todayWorkout == null) {
      return _buildWorkoutCardSkeleton(
        child: Center(
          child: Text(
            "No workout available",
            style: GoogleFonts.montserrat(
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      );
    }

    // Calculate total workout duration
    final totalDuration = _todayWorkout!.duration;

    // Calculate estimated calories based on fitness level
    final calories = _todayWorkout!.caloriesBurned;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: AppColors.purpleGradient,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryPurple.withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "TODAY'S WORKOUT",
                    style: GoogleFonts.montserrat(
                      color: Colors.white.withOpacity(0.8),
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _todayWorkout!.name,
                    style: GoogleFonts.josefinSans(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 22,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _todayWorkout!.category,
                    style: GoogleFonts.montserrat(
                      color: Colors.white.withOpacity(0.8),
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.fitness_center,
                  color: Colors.white,
                  size: 32,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildWorkoutStat(totalDuration.toString(), "minutes"),
              _buildWorkoutStat(_todayWorkout!.exercises.length.toString(), "exercises"),
              _buildWorkoutStat(calories.toString(), "calories"),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => WorkoutDetailsPage(workout: _todayWorkout!),
                  ),
                );

              },
              child: Text(
                "START WORKOUT",
                style: GoogleFonts.montserrat(
                  color: AppColors.primaryPurple,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWorkoutCardSkeleton({required Widget child}) {
    return Container(
      width: double.infinity,
      height: 200,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: AppColors.purpleGradient,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryPurple.withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: child,
    );
  }


  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: GoogleFonts.josefinSans(
        color: AppColors.textPrimary,
        fontWeight: FontWeight.bold,
        fontSize: 20,
      ),
    );
  }

  Widget _buildResponsiveFeatureCards(double screenWidth) {
    final isSmallScreen = screenWidth < 600;
    final cardWidth = isSmallScreen
        ? screenWidth - 32 // full width minus padding
        : (screenWidth / 2) - 32; // fit 2 cards in a row with spacing

    return Wrap(
      spacing: 16,
      runSpacing: 16,
      children: _featureCards.map((card) {
        return _buildFeatureCard(
          title: card['title'],
          description: card['description'],
          icon: card['icon'],
          color: card['color'],
          onTap: () {
            Navigator.pushNamed(context, card['route']);
          },
          cardWidth: cardWidth,
        );
      }).toList(),
    );
  }



  Widget _buildFeatureCard({
    required String title,
    required String description,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    required double cardWidth,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: cardWidth,
        margin: const EdgeInsets.only(right: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.darkCard,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: GoogleFonts.josefinSans(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              description,
              style: GoogleFonts.montserrat(
                color: AppColors.textSecondary,
                fontSize: 12,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }





}