import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import '../core/constant.dart';
import '../core/helper.dart';

class BMICalculatorScreen extends StatefulWidget {
  const BMICalculatorScreen({super.key});

  @override
  State<BMICalculatorScreen> createState() => _BMICalculatorScreenState();
}

class _BMICalculatorScreenState extends State<BMICalculatorScreen> with SingleTickerProviderStateMixin {
  // Controllers for input fields
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();


  // Animation controllers
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // BMI calculation variables
  double _bmi = 0.0;
  String _bmiCategory = '';
  bool _hasCalculated = false;
  String _userId = '';

  // State variables for unit selections
  bool _isMetric = true; // true for metric (cm/kg), false for imperial (in/lbs)
  String _gender = 'male'; // default to male

  @override
  void initState() {
    super.initState();
    _userId = FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';

    // Initialize animations
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(
        begin: 0.0,
        end: 1.0
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    super.dispose();
  }

  // Calculate BMI based on height and weight
  void _calculateBMI() {
    if (_heightController.text.isEmpty || _weightController.text.isEmpty) {
      Helper.showSnackBar(context, "Please enter both height and weight.");
      return;
    }

    double height;
    double weight;

    try {
      height = double.parse(_heightController.text);
      weight = double.parse(_weightController.text);

      if (height <= 0 || weight <= 0) {
        Helper.showSnackBar(
            context, "Height and weight must be positive values.");
        return;
      }

      // Convert units if needed
      if (_isMetric) {
        // Formula: weight (kg) / (height (m))^2
        height = height / 100; // Convert cm to m
        _bmi = weight / (height * height);
      } else {
        // Formula for imperial: (weight (lbs) * 703) / (height (in))^2
        _bmi = (weight * 703) / (height * height);
      }

      // Determine BMI category
      if (_bmi < 18.5) {
        _bmiCategory = 'Underweight';
      } else if (_bmi < 25) {
        _bmiCategory = 'Normal weight';
      } else if (_bmi < 30) {
        _bmiCategory = 'Overweight';
      } else {
        _bmiCategory = 'Obesity';
      }

      setState(() {
        _hasCalculated = true;
      });

      // Save BMI result to Firebase
      _saveBmiToFirebase();
    } catch (e) {
      Helper.showSnackBar(
          context, "Please enter valid numbers for height and weight.");
    }
  }

  // Save BMI result to Firebase
  Future<void> _saveBmiToFirebase() async {
    try {
      final DatabaseReference bmiRef = FirebaseDatabase.instance
          .ref()
          .child('bmi_records')
          .child(_userId);

      // Create a new entry with timestamp
      final newBmiRef = bmiRef.push();
      await newBmiRef.set({
        'bmi': _bmi,
        'category': _bmiCategory,
        'height': _heightController.text,
        'weight': _weightController.text,
        'units': _isMetric ? 'metric' : 'imperial',
        'gender': _gender,
        'timestamp': DateTime
            .now()
            .millisecondsSinceEpoch,
      });
    } catch (e) {
      Helper.showSnackBar(context, "Failed to save BMI record: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "BMI CALCULATOR",
          style: GoogleFonts.josefinSans(
            color: AppColors.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
      ),
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF121212),
                  Color(0xFF1E1E2E),
                ],
              ),
            ),
          ),

          // Background Shape - top right circle
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.purpleGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // Background Shape - bottom left circle
          Positioned(
            bottom: -120,
            left: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.accentGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accentPink.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // BMI Info Card
                      Card(
                        color: AppColors.darkCard,
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "BMI (Body Mass Index)",
                                style: GoogleFonts.montserrat(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.primaryPurple,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "BMI is a measure of body fat based on height and weight. It can help you determine if you're at a healthy weight.",
                                style: GoogleFonts.montserrat(
                                  fontSize: 14,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Unit Selection
                      Card(
                        color: AppColors.darkCard,
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Units",
                                style: GoogleFonts.montserrat(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _isMetric = true;
                                        });
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        decoration: BoxDecoration(
                                          gradient: _isMetric
                                              ? const LinearGradient(
                                            colors: AppColors.purpleGradient,
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          )
                                              : null,
                                          color: _isMetric ? null : Colors.grey
                                              .withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(
                                              8),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Metric (cm, kg)",
                                            style: GoogleFonts.montserrat(
                                              color: _isMetric
                                                  ? Colors.white
                                                  : AppColors.textSecondary,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _isMetric = false;
                                        });
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        decoration: BoxDecoration(
                                          gradient: !_isMetric
                                              ? const LinearGradient(
                                            colors: AppColors.purpleGradient,
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          )
                                              : null,
                                          color: !_isMetric ? null : Colors.grey
                                              .withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(
                                              8),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Imperial (in, lbs)",
                                            style: GoogleFonts.montserrat(
                                              color: !_isMetric
                                                  ? Colors.white
                                                  : AppColors.textSecondary,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Gender Selection
                      Card(
                        color: AppColors.darkCard,
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Gender",
                                style: GoogleFonts.montserrat(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _gender = 'male';
                                        });
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        decoration: BoxDecoration(
                                          gradient: _gender == 'male'
                                              ? const LinearGradient(
                                            colors: AppColors.purpleGradient,
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          )
                                              : null,
                                          color: _gender == 'male'
                                              ? null
                                              : Colors.grey.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(
                                              8),
                                        ),
                                        child: Column(
                                          children: [
                                            Icon(
                                              Icons.male,
                                              color: _gender == 'male'
                                                  ? Colors.white
                                                  : AppColors.textSecondary,
                                              size: 32,
                                            ),
                                            const SizedBox(height: 8),
                                            Text(
                                              "Male",
                                              style: GoogleFonts.montserrat(
                                                color: _gender == 'male'
                                                    ? Colors.white
                                                    : AppColors.textSecondary,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _gender = 'female';
                                        });
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        decoration: BoxDecoration(
                                          gradient: _gender == 'female'
                                              ? const LinearGradient(
                                            colors: AppColors.accentGradient,
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          )
                                              : null,
                                          color: _gender == 'female'
                                              ? null
                                              : Colors.grey.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(
                                              8),
                                        ),
                                        child: Column(
                                          children: [
                                            Icon(
                                              Icons.female,
                                              color: _gender == 'female'
                                                  ? Colors.white
                                                  : AppColors.textSecondary,
                                              size: 32,
                                            ),
                                            const SizedBox(height: 8),
                                            Text(
                                              "Female",
                                              style: GoogleFonts.montserrat(
                                                color: _gender == 'female'
                                                    ? Colors.white
                                                    : AppColors.textSecondary,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Height and Weight Inputs
                      Card(
                        color: AppColors.darkCard,
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Height input
                              Text(
                                "Height",
                                style: GoogleFonts.montserrat(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                      color: AppColors.textSecondary
                                          .withOpacity(0.3)),
                                ),
                                child: TextField(
                                  controller: _heightController,
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: _isMetric
                                        ? "Height in cm"
                                        : "Height in inches",
                                    hintStyle: TextStyle(
                                        color: AppColors.textSecondary),
                                    border: InputBorder.none,
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 14),
                                    suffixText: _isMetric ? "cm" : "in",
                                    suffixStyle: TextStyle(
                                        color: AppColors.textSecondary),
                                  ),
                                  style: TextStyle(
                                      color: AppColors.textPrimary),
                                ),
                              ),

                              const SizedBox(height: 20),

                              // Weight input
                              Text(
                                "Weight",
                                style: GoogleFonts.montserrat(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                      color: AppColors.textSecondary
                                          .withOpacity(0.3)),
                                ),
                                child: TextField(
                                  controller: _weightController,
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: _isMetric
                                        ? "Weight in kg"
                                        : "Weight in lbs",
                                    hintStyle: TextStyle(
                                        color: AppColors.textSecondary),
                                    border: InputBorder.none,
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 14),
                                    suffixText: _isMetric ? "kg" : "lbs",
                                    suffixStyle: TextStyle(
                                        color: AppColors.textSecondary),
                                  ),
                                  style: TextStyle(
                                      color: AppColors.textPrimary),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Calculate Button
                      Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: AppColors.purpleGradient,
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primaryPurple.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _calculateBMI,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text(
                            "CALCULATE",
                            style: GoogleFonts.montserrat(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Results Section
                      if (_hasCalculated)
                        Card(
                          color: AppColors.darkCard,
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                Text(
                                  "Your BMI Result",
                                  style: GoogleFonts.montserrat(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: const LinearGradient(
                                      colors: AppColors.purpleGradient,
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: AppColors.primaryPurple
                                            .withOpacity(0.3),
                                        blurRadius: 10,
                                        spreadRadius: 2,
                                      ),
                                    ],
                                  ),
                                  child: Text(
                                    _bmi.toStringAsFixed(1),
                                    style: GoogleFonts.montserrat(
                                      fontSize: 36,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  _bmiCategory,
                                  style: GoogleFonts.montserrat(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: Helper.getBmiCategoryColor(_bmiCategory),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  Helper.getBmiMessage(_bmiCategory),
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.montserrat(
                                    fontSize: 14,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}