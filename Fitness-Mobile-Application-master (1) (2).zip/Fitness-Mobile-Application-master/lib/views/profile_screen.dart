import 'package:fitness_buddy_mobile/core/routes.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constant.dart';
import '../core/helper.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  final _ageController = TextEditingController();
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  String _selectedFitnessLevel = 'Beginner';
  final List<String> _fitnessLevels = ['Beginner', 'Intermediate', 'Advanced', 'Professional'];

  bool _isLoading = false;
  bool _isCurrentPasswordVisible = false;
  bool _isNewPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool _changePassword = false;

  String _userId = '';
  String _userEmail = '';

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _animationController.forward();
    _loadUserData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _nameController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    _ageController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      _userId = prefs.getString('uid') ?? '';
      _userEmail = prefs.getString('email') ?? '';

      if (_userId.isNotEmpty) {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(_userId)
            .get();

        if (userDoc.exists) {
          Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;

          setState(() {
            _nameController.text = userData['name'] ?? '';
            _heightController.text = (userData['height'] ?? '').toString();
            _weightController.text = (userData['weight'] ?? '').toString();
            _ageController.text = (userData['age'] ?? '').toString();
            _selectedFitnessLevel = userData['fitnessLevel'] ?? 'Beginner';
          });
        }
      }
    } catch (error) {
      Helper.showSnackBar(context, "Failed to load profile data: ${error.toString()}");
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _togglePasswordVisibility(String field) {
    setState(() {
      switch (field) {
        case 'current':
          _isCurrentPasswordVisible = !_isCurrentPasswordVisible;
          break;
        case 'new':
          _isNewPasswordVisible = !_isNewPasswordVisible;
          break;
        case 'confirm':
          _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
          break;
      }
    });
  }

  Future<void> _updateProfile() async {
    if (_formKey.currentState?.validate() ?? false) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Update Firestore data
        await FirebaseFirestore.instance.collection('users').doc(_userId).update({
          'name': _nameController.text.trim(),
          'height': double.tryParse(_heightController.text.trim()) ?? 0.0,
          'weight': double.tryParse(_weightController.text.trim()) ?? 0.0,
          'age': int.tryParse(_ageController.text.trim()) ?? 0,
          'fitnessLevel': _selectedFitnessLevel,
          'updatedAt': FieldValue.serverTimestamp(),
        });

        // Update SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('fullName', _nameController.text.trim());
        await prefs.setDouble('height', double.tryParse(_heightController.text.trim()) ?? 0.0);
        await prefs.setDouble('weight', double.tryParse(_weightController.text.trim()) ?? 0.0);
        await prefs.setInt('age', int.tryParse(_ageController.text.trim()) ?? 0);
        await prefs.setString('fitnessLevel', _selectedFitnessLevel);

        // Handle password change if requested
        if (_changePassword &&
            _currentPasswordController.text.trim().isNotEmpty &&
            _newPasswordController.text.trim().isNotEmpty) {

          // Re-authenticate user before changing password
          User? user = FirebaseAuth.instance.currentUser;
          if (user != null) {
            AuthCredential credential = EmailAuthProvider.credential(
              email: _userEmail,
              password: _currentPasswordController.text.trim(),
            );

            await user.reauthenticateWithCredential(credential);
            await user.updatePassword(_newPasswordController.text.trim());
          }
        }

        Helper.showSnackBar(context, "Profile updated successfully!");
      } on FirebaseAuthException catch (e) {
        String message;
        switch (e.code) {
          case 'wrong-password':
            message = 'Current password is incorrect.';
            break;
          case 'weak-password':
            message = 'New password is too weak.';
            break;
          default:
            message = 'Failed to update profile: ${e.message}';
        }
        Helper.showSnackBar(context, message);
      } catch (error) {
        Helper.showSnackBar(context, "Unexpected error: ${error.toString()}");
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Edit Profile",
          style: GoogleFonts.josefinSans(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
      ),
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF121212),
                  Color(0xFF1E1E2E),
                ],
              ),
            ),
          ),

          // Background shapes
          Positioned(
            top: -150,
            right: -100,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.purpleGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            bottom: -120,
            left: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.accentGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accentPink.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // Content
          _isLoading
              ? const Center(
            child: CircularProgressIndicator(
              color: AppColors.accentPink,
            ),
          )
              : SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),

                  // Profile Image
                  Center(
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: Column(
                        children: [
                          Stack(
                            children: [
                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.darkCard,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.primaryPurple.withOpacity(0.2),
                                      blurRadius: 15,
                                      spreadRadius: 3,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.person,
                                  size: 60,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: const LinearGradient(
                                      colors: AppColors.purpleGradient,
                                    ),
                                  ),
                                  child: const Icon(
                                    Icons.camera_alt,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            _userEmail,
                            style: GoogleFonts.montserrat(
                              fontSize: 14,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Form Header
                  SlideTransition(
                    position: _slideAnimation,
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: Text(
                        "Personal Information",
                        style: GoogleFonts.josefinSans(
                          fontSize: 22,
                          letterSpacing: 1.0,
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Profile Form
                  SlideTransition(
                    position: _slideAnimation,
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Name Field
                            TextFormField(
                              controller: _nameController,
                              decoration: InputDecoration(
                                labelText: "Full Name",
                                prefixIcon: const Icon(
                                  Icons.person_outline,
                                  color: AppColors.textSecondary,
                                ),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: TextStyle(color: AppColors.textPrimary),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your name";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Height Field
                            TextFormField(
                              controller: _heightController,
                              decoration: InputDecoration(
                                labelText: "Height (cm)",
                                prefixIcon: const Icon(
                                  Icons.height,
                                  color: AppColors.textSecondary,
                                ),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: TextStyle(color: AppColors.textPrimary),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your height";
                                }
                                try {
                                  double height = double.parse(value);
                                  if (height <= 0) {
                                    return "Height must be greater than 0";
                                  }
                                } catch (e) {
                                  return "Please enter a valid number";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Weight Field
                            TextFormField(
                              controller: _weightController,
                              decoration: InputDecoration(
                                labelText: "Weight (kg)",
                                prefixIcon: const Icon(
                                  Icons.fitness_center,
                                  color: AppColors.textSecondary,
                                ),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: TextStyle(color: AppColors.textPrimary),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your weight";
                                }
                                try {
                                  double weight = double.parse(value);
                                  if (weight <= 0) {
                                    return "Weight must be greater than 0";
                                  }
                                } catch (e) {
                                  return "Please enter a valid number";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Age Field
                            TextFormField(
                              controller: _ageController,
                              decoration: InputDecoration(
                                labelText: "Age",
                                prefixIcon: const Icon(
                                  Icons.calendar_today,
                                  color: AppColors.textSecondary,
                                ),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: TextStyle(color: AppColors.textPrimary),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your age";
                                }
                                try {
                                  int age = int.parse(value);
                                  if (age <= 0) {
                                    return "Age must be greater than 0";
                                  }
                                } catch (e) {
                                  return "Please enter a valid number";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 25),

                            // Fitness Level Dropdown
                            Text(
                              "Fitness Level",
                              style: GoogleFonts.montserrat(
                                fontSize: 16,
                                color: AppColors.textPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),

                            const SizedBox(height: 10),

                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 15),
                              decoration: BoxDecoration(
                                color: AppColors.darkCard.withOpacity(0.5),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: AppColors.textSecondary.withOpacity(0.3)),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  value: _selectedFitnessLevel,
                                  icon: const Icon(
                                    Icons.arrow_drop_down,
                                    color: AppColors.textSecondary,
                                  ),
                                  isExpanded: true,
                                  dropdownColor: AppColors.darkCard,
                                  style: TextStyle(color: AppColors.textPrimary),
                                  items: _fitnessLevels.map((String level) {
                                    return DropdownMenuItem<String>(
                                      value: level,
                                      child: Text(level),
                                    );
                                  }).toList(),
                                  onChanged: (String? newValue) {
                                    if (newValue != null) {
                                      setState(() {
                                        _selectedFitnessLevel = newValue;
                                      });
                                    }
                                  },
                                ),
                              ),
                            ),

                            const SizedBox(height: 30),

                            // Change Password Toggle
                            GestureDetector(
                              onTap: () {
                                setState(() {
                                  _changePassword = !_changePassword;
                                });
                              },
                              child: Row(
                                children: [
                                  Icon(
                                    _changePassword
                                        ? Icons.check_box
                                        : Icons.check_box_outline_blank,
                                    color: AppColors.accentPink,
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    "Change Password",
                                    style: GoogleFonts.montserrat(
                                      fontSize: 16,
                                      color: AppColors.textPrimary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            // Password Fields
                            if (_changePassword) ...[
                              // Current Password
                              TextFormField(
                                controller: _currentPasswordController,
                                obscureText: !_isCurrentPasswordVisible,
                                decoration: InputDecoration(
                                  labelText: "Current Password",
                                  prefixIcon: const Icon(
                                    Icons.lock_outline,
                                    color: AppColors.textSecondary,
                                  ),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _isCurrentPasswordVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      color: AppColors.textSecondary,
                                    ),
                                    onPressed: () => _togglePasswordVisibility('current'),
                                  ),
                                  labelStyle: TextStyle(color: AppColors.textSecondary),
                                ),
                                style: TextStyle(color: AppColors.textPrimary),
                                validator: (value) {
                                  if (_changePassword) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your current password";
                                    }
                                    if (value.length < 6) {
                                      return "Password must be at least 6 characters";
                                    }
                                  }
                                  return null;
                                },
                              ),

                              const SizedBox(height: 20),

                              // New Password
                              TextFormField(
                                controller: _newPasswordController,
                                obscureText: !_isNewPasswordVisible,
                                decoration: InputDecoration(
                                  labelText: "New Password",
                                  prefixIcon: const Icon(
                                    Icons.lock_outline,
                                    color: AppColors.textSecondary,
                                  ),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _isNewPasswordVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      color: AppColors.textSecondary,
                                    ),
                                    onPressed: () => _togglePasswordVisibility('new'),
                                  ),
                                  labelStyle: TextStyle(color: AppColors.textSecondary),
                                ),
                                style: TextStyle(color: AppColors.textPrimary),
                                validator: (value) {
                                  if (_changePassword) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your new password";
                                    }
                                    if (value.length < 6) {
                                      return "Password must be at least 6 characters";
                                    }
                                  }
                                  return null;
                                },
                              ),

                              const SizedBox(height: 20),

                              // Confirm Password
                              TextFormField(
                                controller: _confirmPasswordController,
                                obscureText: !_isConfirmPasswordVisible,
                                decoration: InputDecoration(
                                  labelText: "Confirm New Password",
                                  prefixIcon: const Icon(
                                    Icons.lock_outline,
                                    color: AppColors.textSecondary,
                                  ),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _isConfirmPasswordVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      color: AppColors.textSecondary,
                                    ),
                                    onPressed: () => _togglePasswordVisibility('confirm'),
                                  ),
                                  labelStyle: TextStyle(color: AppColors.textSecondary),
                                ),
                                style: TextStyle(color: AppColors.textPrimary),
                                validator: (value) {
                                  if (_changePassword) {
                                    if (value == null || value.isEmpty) {
                                      return "Please confirm your new password";
                                    }
                                    if (value != _newPasswordController.text) {
                                      return "Passwords do not match";
                                    }
                                  }
                                  return null;
                                },
                              ),
                            ],

                            const SizedBox(height: 40),

                            // Update Button
                            Container(
                              width: double.infinity,
                              height: 55,
                              decoration: Helper.gradientBoxDecoration(AppColors.purpleGradient),
                              child: ElevatedButton(
                                onPressed: _updateProfile,
                                style: ElevatedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  elevation: 0,
                                ),
                                child: _isLoading
                                    ? const CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 3,
                                )
                                    : const Text(
                                  "Update Profile",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: "Poppins",
                                    letterSpacing: 1.2,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}