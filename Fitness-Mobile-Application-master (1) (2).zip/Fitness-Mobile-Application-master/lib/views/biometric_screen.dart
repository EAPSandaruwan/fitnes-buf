// screens/biometrics_screen.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart'; // Import for date formatting
import '../core/constant.dart';
import '../core/helper.dart';
import '../models/user_model.dart';

class BiometricsScreen extends StatefulWidget {
  final Map<String, String> userData;

  const BiometricsScreen({super.key, required this.userData});

  @override
  State<BiometricsScreen> createState() => _BiometricsScreenState();
}

class _BiometricsScreenState extends State<BiometricsScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final _formKey = GlobalKey<FormState>();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  final _birthdateController = TextEditingController();
  String? _selectedGender;
  DateTime? _selectedDate;
  bool _isLoading = false;

  final List<String> _genderOptions = ['Male', 'Female', 'Other', 'Prefer not to say'];

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeIn,
      ),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOut,
      ),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    _birthdateController.dispose();
    super.dispose();
  }

  // Show date picker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime(2000, 1, 1),
      firstDate: DateTime(1920, 1, 1),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.dark(
              primary: AppColors.primaryPurple,
              onPrimary: Colors.white,
              onSurface: AppColors.textPrimary,
            ),
            dialogBackgroundColor: AppColors.darkCard,
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
        _birthdateController.text = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  // Calculate age from birthdate
  int _calculateAge(String birthdate) {
    DateTime birth = DateTime.parse(birthdate);
    DateTime today = DateTime.now();
    int age = today.year - birth.year;
    if (today.month < birth.month || (today.month == birth.month && today.day < birth.day)) {
      age--;
    }
    return age;
  }

  void _handleComplete() async {
    if (_formKey.currentState?.validate() ?? false) {
      setState(() {
        _isLoading = true; // Show loading state
      });

      try {
        // Register the user with Firebase Authentication
        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: widget.userData['email']!,
          password: widget.userData['password']!,
        );

        // Get Firebase User ID
        String uid = userCredential.user!.uid;

        // Calculate age from birthdate
        int age = _calculateAge(_birthdateController.text);

        // Create UserModel object
        UserModel user = UserModel(
          uid: uid,
          name: widget.userData['name']!,
          email: widget.userData['email']!,
          age: age,
          height: double.parse(_heightController.text),
          weight: double.parse(_weightController.text),
          gender: _selectedGender!,
          fitnessLevel: 'Beginner', // Can be updated later
        );

        // Save user data in Firestore
        await FirebaseFirestore.instance.collection('users').doc(uid).set(user.toMap());

        // Show success message
        Helper.showSnackBar(context, "Registration successful!");

        // Navigate to home screen
        Navigator.pushReplacementNamed(context, '/home');
      } catch (e) {
        // Handle errors
        Helper.showSnackBar(context, "Error: ${e.toString()}");
      } finally {
        // Hide loading state if still mounted
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF121212),
                  Color(0xFF1E1E2E),
                ],
              ),
            ),
          ),

          // Background shapes
          Positioned(
            top: -120,
            left: -70,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.accentGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accentPink.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            bottom: -150,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: AppColors.purpleGradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryPurple.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // Biometrics content
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Back button
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back_ios, color: AppColors.textPrimary),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Logo and app name
                  Center(
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: Text(
                        "FITNESS BUDDY",
                        style: GoogleFonts.josefinSans(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Biometrics info text
                  SlideTransition(
                    position: _slideAnimation,
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Your Fitness Details",
                            style: GoogleFonts.josefinSans(
                              fontSize: 24,
                              letterSpacing: 1.2,
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Help us customize your fitness experience",
                            style: GoogleFonts.montserrat(
                              color: AppColors.textSecondary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Biometrics form
                  SlideTransition(
                    position: _slideAnimation,
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            // Birthdate field
                            TextFormField(
                              controller: _birthdateController,
                              readOnly: true,
                              decoration: InputDecoration(
                                labelText: "Birthdate",
                                prefixIcon: const Icon(Icons.calendar_today, color: AppColors.textSecondary),
                                suffixIcon: IconButton(
                                  icon: const Icon(Icons.date_range, color: AppColors.textSecondary),
                                  onPressed: () => _selectDate(context),
                                ),
                                labelStyle: const TextStyle(color: AppColors.textSecondary),
                              ),
                              style: const TextStyle(color: AppColors.textPrimary),
                              onTap: () => _selectDate(context),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please select your birthdate";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Gender dropdown
                            DropdownButtonFormField<String>(
                              value: _selectedGender,
                              decoration: const InputDecoration(
                                labelText: "Gender",
                                prefixIcon: Icon(Icons.people_outline, color: AppColors.textSecondary),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: const TextStyle(color: AppColors.textPrimary),
                              dropdownColor: AppColors.darkCard,
                              items: _genderOptions.map((gender) {
                                return DropdownMenuItem(
                                  value: gender,
                                  child: Text(gender),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  _selectedGender = value;
                                });
                              },
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please select your gender";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Height field
                            TextFormField(
                              controller: _heightController,
                              decoration: const InputDecoration(
                                labelText: "Height (cm)",
                                prefixIcon: Icon(Icons.height, color: AppColors.textSecondary),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: const TextStyle(color: AppColors.textPrimary),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your height";
                                }
                                try {
                                  double height = double.parse(value);
                                  if (height <= 0 || height > 300) {
                                    return "Please enter a valid height";
                                  }
                                } catch (e) {
                                  return "Please enter a valid number";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 20),

                            // Weight field
                            TextFormField(
                              controller: _weightController,
                              decoration: const InputDecoration(
                                labelText: "Weight (kg)",
                                prefixIcon: Icon(Icons.fitness_center, color: AppColors.textSecondary),
                                labelStyle: TextStyle(color: AppColors.textSecondary),
                              ),
                              style: const TextStyle(color: AppColors.textPrimary),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter your weight";
                                }
                                try {
                                  double weight = double.parse(value);
                                  if (weight <= 0 || weight > 500) {
                                    return "Please enter a valid weight";
                                  }
                                } catch (e) {
                                  return "Please enter a valid number";
                                }
                                return null;
                              },
                            ),

                            const SizedBox(height: 30),

                            // Terms and conditions
                            Row(
                              children: [
                                Checkbox(
                                  value: true,
                                  onChanged: (value) {},
                                  activeColor: AppColors.primaryPurple,
                                ),
                                Expanded(
                                  child: RichText(
                                    text: TextSpan(
                                      style: GoogleFonts.montserrat(color: AppColors.textSecondary, fontSize: 12, fontWeight: FontWeight.w600),
                                      children: [
                                        const TextSpan(text: "By creating an account, you agree to our "),
                                        TextSpan(
                                          text: "Terms & Conditions",
                                          style: TextStyle(color: AppColors.accentPink, fontWeight: FontWeight.bold),
                                        ),
                                        const TextSpan(text: " and "),
                                        TextSpan(
                                          text: "Privacy Policy",
                                          style: TextStyle(color: AppColors.accentPink, fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),


                            const SizedBox(height: 50),

                            // Complete registration button
                            Container(
                              width: double.infinity,
                              height: 55,
                              decoration: Helper.gradientBoxDecoration(AppColors.purpleGradient),
                              child: ElevatedButton(
                                onPressed: _handleComplete,
                                style: ElevatedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  elevation: 0,
                                ),
                                child: Text(
                                  "SIGN UP",
                                  style: GoogleFonts.poppins(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}