import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constant.dart';
import '../core/helper.dart';
import '../core/routes.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 24),
              _buildSettingsCard(
                context,
                icon: Icons.person,
                title: "Edit Profile",
                subtitle: "Update your personal information",
                iconColor: AppColors.primaryPurple,
                onTap: () => Navigator.pushNamed(context, Routes.profile),
              ),
              const SizedBox(height: 16),
              _buildSettingsCard(
                context,
                icon: Icons.health_and_safety_outlined,
                title: "BMI Calculator",
                subtitle: "Check your Body Mass Index",
                iconColor: AppColors.accentTeal,
                onTap: () => Navigator.pushNamed(context, Routes.bmiCalculator),
              ),
              const SizedBox(height: 16),
              _buildSettingsCard(
                context,
                icon: Icons.help_outline,
                title: "Help & Support",
                subtitle: "Get assistance and answers to common questions",
                iconColor: AppColors.textSecondary,
                onTap: () {
                  // Navigate to help page when implemented
                  // Navigator.pushNamed(context, Routes.help);
                  Helper.showSnackBar(context, "Help & Support page coming soon");
                },
              ),
              const SizedBox(height: 24),
              _buildSignOutButton(context),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSettingsCard(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String subtitle,
        required Color iconColor,
        required VoidCallback onTap,
      }) {
    return Card(
      elevation: 2,
      color: AppColors.darkCard,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: iconColor,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.montserrat(
                        color: AppColors.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: GoogleFonts.montserrat(
                        color: AppColors.textSecondary,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios,
                color: AppColors.textSecondary,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSignOutButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () => _signOut(context),
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.darkCard,
          foregroundColor: AppColors.accentPink,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: AppColors.accentPink),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.logout, size: 20),
            const SizedBox(width: 8),
            Text(
              "Sign Out",
              style: GoogleFonts.montserrat(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _signOut(BuildContext context) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();

      await FirebaseAuth.instance.signOut();
      Navigator.pushReplacementNamed(context, Routes.login);
      Helper.showSnackBar(context, "Signed out successfully");
    } catch(error) {
      Helper.showSnackBar(context, "Sign out failed: ${error.toString()}");
    }
  }
}