import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fitness_buddy_mobile/core/constant.dart';
import 'package:fitness_buddy_mobile/models/progress_model.dart';
import 'package:fitness_buddy_mobile/views/bmi_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  List<ProgressModel> progressData = [];
  bool isLoading = true;
  String selectedMetric = 'Workout Duration';

  @override
  void initState() {
    super.initState();
    fetchProgressData();
  }

  Future<void> fetchProgressData() async {
    try {
      final _sharedPreferences = SharedPreferences.getInstance();

      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      // Get the last 7 days of progress data
      final endDate = DateTime.now();
      final startDate = endDate.subtract(const Duration(days: 7));

      final querySnapshot = await _firestore
          .collection('progress')
          .where('userId', isEqualTo: userId)
          .where('date', isGreaterThanOrEqualTo: startDate.toIso8601String())
          .where('date', isLessThanOrEqualTo: endDate.toIso8601String())
          .orderBy('date', descending: false)
          .get();

      final data = querySnapshot.docs
          .map((doc) => ProgressModel.fromMap(doc.data()))
          .toList();

      setState(() {
        progressData = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error fetching progress data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(
          color: AppColors.primaryPurple,
        ),
      )
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),
            _buildBMICard(),
            const SizedBox(height: 24),
            _buildMetricSelector(),
            const SizedBox(height: 16),
            _buildProgressChart(),
            const SizedBox(height: 24),
            _buildStatsCards(),
            const SizedBox(height: 24),
            _buildRecentWorkoutsSection(),
          ],
        ),
      ),
    );
  }



  Widget _buildBMICard() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const BMICalculatorScreen()),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: AppColors.purpleGradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primaryPurple.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Calculate Your BMI",
                  style: GoogleFonts.montserrat(
                    color: AppColors.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Track your body mass index",
                  style: GoogleFonts.montserrat(
                    color: AppColors.textPrimary.withOpacity(0.8),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.arrow_forward,
                color: AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricSelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.darkCard,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "View Progress:",
            style: GoogleFonts.montserrat(
              color: AppColors.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          DropdownButton<String>(
            value: selectedMetric,
            dropdownColor: AppColors.darkBackground,
            style: GoogleFonts.montserrat(
              color: AppColors.primaryPurple,
              fontSize: 16,
            ),
            icon: const Icon(Icons.arrow_drop_down, color: AppColors.primaryPurple),
            underline: Container(),
            onChanged: (String? newValue) {
              setState(() {
                selectedMetric = newValue!;
              });
            },
            items: <String>[
              'Workout Duration',
              'Calories Burned',
              'Weight'
            ].map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressChart() {
    if (progressData.isEmpty) {
      return Container(
        height: 200,
        alignment: Alignment.center,
        child: Text(
          "No progress data available yet",
          style: GoogleFonts.montserrat(
            color: AppColors.textSecondary,
            fontSize: 16,
          ),
        ),
      );
    }

    // Sort data by date
    progressData.sort((a, b) => a.date.compareTo(b.date));

    // Prepare data based on selected metric
    List<FlSpot> spots = [];
    double maxY = 0;

    for (int i = 0; i < progressData.length; i++) {
      double yValue;

      switch (selectedMetric) {
        case 'Workout Duration':
          yValue = progressData[i].workoutMinutes.toDouble();
          maxY = max(maxY, yValue);
          break;
        case 'Calories Burned':
          yValue = progressData[i].caloriesBurned.toDouble();
          maxY = max(maxY, yValue);
          break;
        case 'Weight':
          yValue = progressData[i].weight;
          if (i == 0) maxY = yValue + 5;
          maxY = max(maxY, yValue);
          break;
        default:
          yValue = progressData[i].workoutMinutes.toDouble();
          maxY = max(maxY, yValue);
      }

      spots.add(FlSpot(i.toDouble(), yValue));
    }

    return Container(
      height: 280,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            selectedMetric,
            style: GoogleFonts.montserrat(
              color: AppColors.textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: maxY / 5,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: AppColors.textSecondary.withOpacity(0.2),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= progressData.length || value.toInt() < 0) {
                          return const SizedBox();
                        }
                        final date = progressData[value.toInt()].date;
                        return Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            DateFormat('MM/dd').format(date),
                            style: GoogleFonts.montserrat(
                              color: AppColors.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        String text = value.toInt().toString();
                        if (selectedMetric == 'Weight') {
                          text = value.toStringAsFixed(1);
                        }
                        return Text(
                          text,
                          style: GoogleFonts.montserrat(
                            color: AppColors.textSecondary,
                            fontSize: 12,
                          ),
                        );
                      },
                    ),
                  ),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                borderData: FlBorderData(show: false),
                minX: 0,
                maxX: progressData.length.toDouble() - 1,
                minY: 0,
                maxY: maxY * 1.2,
                lineBarsData: [
                  LineChartBarData(
                    spots: spots,
                    isCurved: true,
                    color: AppColors.primaryPurple,
                    barWidth: 3,
                    isStrokeCapRound: true,
                    dotData: FlDotData(
                      show: true,
                      getDotPainter: (spot, percent, barData, index) {
                        return FlDotCirclePainter(
                          radius: 5,
                          color: AppColors.accentPink,
                          strokeWidth: 0,
                        );
                      },
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      color: AppColors.primaryPurple.withOpacity(0.2),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCards() {
    // Calculate the averages and totals
    int totalMinutes = 0;
    int totalCalories = 0;
    double initialWeight = 0;
    double currentWeight = 0;

    if (progressData.isNotEmpty) {
      for (var progress in progressData) {
        totalMinutes += progress.workoutMinutes;
        totalCalories += progress.caloriesBurned;
      }

      // Sort by date for weight comparison
      progressData.sort((a, b) => a.date.compareTo(b.date));
      if (progressData.isNotEmpty) {
        initialWeight = progressData.first.weight;
        currentWeight = progressData.last.weight;
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Weekly Stats",
          style: GoogleFonts.montserrat(
            color: AppColors.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                "Total Workout Time",
                "$totalMinutes min",
                Icons.timer_outlined,
                AppColors.primaryPurple,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                "Calories Burned",
                "$totalCalories kcal",
                Icons.local_fire_department_outlined,
                AppColors.accentPink,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                "Average Daily",
                "${(totalMinutes / max(progressData.length, 1)).toStringAsFixed(1)} min",
                Icons.calendar_today_outlined,
                AppColors.primaryBlue,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                "Weight Change",
                "${(currentWeight - initialWeight).toStringAsFixed(1)} kg",
                Icons.monitor_weight_outlined,
                initialWeight > currentWeight
                    ? Colors.green
                    : initialWeight < currentWeight
                    ? Colors.orange
                    : AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: color,
                size: 22,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.montserrat(
                    color: AppColors.textSecondary,
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.montserrat(
              color: AppColors.textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentWorkoutsSection() {
    // Sort by date (most recent first)
    final recentProgress = List<ProgressModel>.from(progressData)
      ..sort((a, b) => b.date.compareTo(a.date));

    // Take only the most recent 3
    final recentWorkouts = recentProgress.take(3).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Recent Workouts",
          style: GoogleFonts.montserrat(
            color: AppColors.textPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        recentWorkouts.isEmpty
            ? Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.darkCard,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Center(
            child: Text(
              "No recent workouts available",
              style: GoogleFonts.montserrat(
                color: AppColors.textSecondary,
                fontSize: 16,
              ),
            ),
          ),
        )
            : Column(
          children: recentWorkouts.map((progress) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12.0),
              child: _buildWorkoutCard(progress),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildWorkoutCard(ProgressModel progress) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primaryPurple.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.fitness_center,
              color: AppColors.primaryPurple,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat.yMMMd().format(progress.date),
                  style: GoogleFonts.montserrat(
                    color: AppColors.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Duration: ${progress.workoutMinutes} minutes",
                  style: GoogleFonts.montserrat(
                    color: AppColors.textSecondary,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                "${progress.caloriesBurned} kcal",
                style: GoogleFonts.montserrat(
                  color: AppColors.accentPink,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "${progress.weight} kg",
                style: GoogleFonts.montserrat(
                  color: AppColors.textSecondary,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}