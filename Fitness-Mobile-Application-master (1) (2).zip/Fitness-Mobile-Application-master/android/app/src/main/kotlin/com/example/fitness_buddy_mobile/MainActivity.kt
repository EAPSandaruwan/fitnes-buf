package com.example.fitness_buddy_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
